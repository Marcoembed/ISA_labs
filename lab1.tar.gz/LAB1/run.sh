cd basic
echo "BASIC"
./run.sh
cd ../adv
echo "ADVANCED"
./run.sh
cd ..
