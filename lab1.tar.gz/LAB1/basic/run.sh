rm -rf netlist
rm -rf reports
rm -rf logs
mkdir netlist
mkdir reports
mkdir logs
cd bash_scripts

echo Simulation
./sim.sh > ../logs/sim.log
cat ../logs/sim.log | grep -i error
echo Synthesys
./syn.sh > ../logs/syn.log
cat ../logs/syn.log | grep -i error
echo Power_analisys
./power.sh > ../logs/power.log
cat ../logs/power.log | grep -i error

