cd ../innovus
source /eda/scripts/init_cadence_2020-2021
innovus -abort_on_error -no_gui -files innovus.cmd
cd -
