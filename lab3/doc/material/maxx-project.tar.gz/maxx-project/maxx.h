#ifndef MAXX_H
#define MAXX_H

void maxx(int pLi, int *pLo, int *psS, int *psE);

#endif
